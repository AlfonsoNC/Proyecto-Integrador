<?php
require('makefont/makefont.php');

//MakeFont('archivo.ttf','archivo.afm');

MakeFont('arial.ttf','arial.afm');
MakeFont('arialbd.ttf','arialbd.afm');
MakeFont('arialbi.ttf','arialbi.afm');
MakeFont('ariali.ttf','ariali.afm');

?>